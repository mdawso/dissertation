Python Version 3.12.8
pip install torch numpy ipykernel
main.py --mode [play, train] to play or train a model